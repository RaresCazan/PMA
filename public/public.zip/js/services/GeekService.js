angular.module('GeekService', []).factory('Geek', ['$http', function($http) {

	

}]);